#pragma once
#include <memory>
#include <string>
#include <boost/asio/io_context.hpp>
#include <boost/asio/ip/tcp.hpp>

// If you have an export macro, include its header and apply it to class server.
#ifndef SKYNET_HTTP_SERVER_SYNC_EXPORT
#define SKYNET_HTTP_SERVER_SYNC_EXPORT
#endif

namespace skynet { namespace http { namespace server { namespace sync {

class SKYNET_HTTP_SERVER_SYNC_EXPORT server {
public:
    server(boost::asio::io_context& io,
           const std::string& address,
           const std::string& port,
           const std::string& doc_root);

    int run(); // blocking accept loop (sync)

private:
    boost::asio::io_context&            m_io;
    boost::asio::ip::tcp::acceptor      m_acceptor;
    std::shared_ptr<const std::string>  m_doc_root;
};

}}}} // namespace
