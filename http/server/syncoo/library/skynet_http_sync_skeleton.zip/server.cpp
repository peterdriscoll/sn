#include "server.hpp"
#include "session.hpp"
#include <boost/asio.hpp>
#include <boost/asio/ip/tcp.hpp>

namespace skynet { namespace http { namespace server { namespace sync {

server::server(boost::asio::io_context& io,
               const std::string& address,
               const std::string& port,
               const std::string& doc_root)
    : m_io(io),
      m_acceptor(io),
      m_doc_root(std::make_shared<const std::string>(doc_root))
{
    boost::asio::ip::tcp::resolver resolver(io);
    auto results = resolver.resolve(address, port);
    auto endpoint = *results.begin();

    m_acceptor.open(endpoint.protocol());
    m_acceptor.set_option(boost::asio::ip::tcp::acceptor::reuse_address(true));
    m_acceptor.bind(endpoint);
    m_acceptor.listen(boost::asio::socket_base::max_listen_connections);
}

int server::run()
{
    for (;;) {
        boost::asio::ip::tcp::socket socket(m_io);
        boost::system::error_code ec;
        m_acceptor.accept(socket, ec);
        if (ec) {
            // optionally log/continue
            continue;
        }
        skynet::http::server::sync::session(std::move(socket), m_doc_root).run();
    }
    // unreachable in normal flow
    // return 0;
}

}}}} // namespace
