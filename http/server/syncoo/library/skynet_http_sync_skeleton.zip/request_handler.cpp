#include "request_handler.hpp"

#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/beast/version.hpp>
#include <fstream>
#include <utility>

// Include your factory header (adjust path)
#include "sn_factory.h"  // SN::SN_Factory<IHTTP_Handler>::CreateObject()

namespace skynet { namespace http { namespace server { namespace sync {

request_handler::request_handler(std::shared_ptr<const std::string> doc_root)
    : m_doc_root(std::move(doc_root))
{
    m_plugin.reset(SN::SN_Factory<IHTTP_Handler>::CreateObject());
}

const char* request_handler::extension_to_type(const std::string& ext)
{
    using boost::beast::iequals;
    if (iequals(ext, "htm")  || iequals(ext, "html")) return "text/html; charset=utf-8";
    if (iequals(ext, "css"))                           return "text/css";
    if (iequals(ext, "txt"))                           return "text/plain; charset=utf-8";
    if (iequals(ext, "js"))                            return "application/javascript";
    if (iequals(ext, "json"))                          return "application/json";
    if (iequals(ext, "xml"))                           return "application/xml";
    if (iequals(ext, "png"))                           return "image/png";
    if (iequals(ext, "jpg") || iequals(ext, "jpeg"))   return "image/jpeg";
    if (iequals(ext, "gif"))                           return "image/gif";
    if (iequals(ext, "bmp"))                           return "image/bmp";
    if (iequals(ext, "ico"))                           return "image/vnd.microsoft.icon";
    if (iequals(ext, "tif") || iequals(ext, "tiff"))   return "image/tiff";
    if (iequals(ext, "svg"))                           return "image/svg+xml";
    if (iequals(ext, "mp4"))                           return "video/mp4";
    if (iequals(ext, "woff"))                          return "font/woff";
    if (iequals(ext, "woff2"))                         return "font/woff2";
    if (iequals(ext, "ttf"))                           return "font/ttf";
    if (iequals(ext, "wasm"))                          return "application/wasm";
    return "application/octet-stream";
}

void request_handler::normalize_target(const boost::beast::string_view& target_sv,
                                       std::string& path_out,
                                       std::string& query_out,
                                       std::string& ext_out)
{
    boost::beast::string_view t = target_sv;
    std::size_t qpos = t.find('?');
    if (qpos != boost::beast::string_view::npos) {
        query_out.assign(t.data() + qpos + 1, t.size() - qpos - 1);
        t = t.substr(0, qpos);
    } else {
        query_out.clear();
    }

    path_out.assign(t.data(), t.size());
    if (path_out.empty() || path_out[0] != '/') path_out = "/";
    if (!path_out.empty() && path_out.back() == '/') path_out += "index.html";

    std::size_t dot = path_out.rfind('.');
    if (dot != std::string::npos && dot + 1 < path_out.size())
        ext_out = path_out.substr(dot + 1); // no leading '.'
    else
        ext_out.clear();
}

boost::beast::http::message_generator
request_handler::handle(boost::beast::http::request<boost::beast::http::string_body>&& req)
{
    namespace http  = boost::beast::http;
    namespace beast = boost::beast;

    std::string path, query, ext;
    normalize_target(req.target(), path, query, ext);

    // 1) Your plugin first (exact port of your old behavior)
    if (m_plugin &&
        m_plugin->handle_response(path.c_str(), query.c_str(), ext.c_str()))
    {
        http::response<http::string_body> res{ http::status::ok, req.version() };
        res.set(http::field::server, BOOST_BEAST_VERSION_STRING);
        res.set(http::field::content_type, extension_to_type(ext));
        res.set(http::field::access_control_allow_origin, "*");
        res.keep_alive(req.keep_alive());
        res.body() = m_plugin->response_data();
        res.prepare_payload();
        return res;
    }

    // 2) Static files: allow only GET/HEAD
    if (req.method() != http::verb::get && req.method() != http::verb::head) {
        http::response<http::string_body> bad{ http::status::bad_request, req.version() };
        bad.set(http::field::server, BOOST_BEAST_VERSION_STRING);
        bad.set(http::field::content_type, "text/plain; charset=utf-8");
        bad.set(http::field::access_control_allow_origin, "*");
        bad.keep_alive(req.keep_alive());
        bad.body() = "Unsupported method";
        bad.prepare_payload();
        return bad;
    }

    std::string full_path(m_doc_root->data(), m_doc_root->size());
    full_path += path;

    beast::error_code ec;
    http::file_body::value_type body;
    body.open(full_path.c_str(), beast::file_mode::scan, ec);

    if (ec == beast::errc::no_such_file_or_directory) {
        http::response<http::string_body> not_found{ http::status::not_found, req.version() };
        not_found.set(http::field::server, BOOST_BEAST_VERSION_STRING);
        not_found.set(http::field::content_type, "text/plain; charset=utf-8");
        not_found.set(http::field::access_control_allow_origin, "*");
        not_found.keep_alive(req.keep_alive());
        not_found.body() = "File not found";
        not_found.prepare_payload();
        return not_found;
    }
    if (ec) {
        http::response<http::string_body> bad{ http::status::internal_server_error, req.version() };
        bad.set(http::field::server, BOOST_BEAST_VERSION_STRING);
        bad.set(http::field::content_type, "text/plain; charset=utf-8");
        bad.set(http::field::access_control_allow_origin, "*");
        bad.keep_alive(req.keep_alive());
        bad.body() = "Error opening file";
        bad.prepare_payload();
        return bad;
    }

    std::uint64_t size = body.size();

    if (req.method() == http::verb::head) {
        http::response<http::empty_body> res{ http::status::ok, req.version() };
        res.set(http::field::server, BOOST_BEAST_VERSION_STRING);
        res.set(http::field::content_type, extension_to_type(ext));
        res.set(http::field::access_control_allow_origin, "*");
        res.keep_alive(req.keep_alive());
        res.content_length(size);
        return res;
    }

    http::response<http::file_body> res{ http::status::ok, req.version() };
    res.set(http::field::server, BOOST_BEAST_VERSION_STRING);
    res.set(http::field::content_type, extension_to_type(ext));
    res.set(http::field::access_control_allow_origin, "*");
    res.keep_alive(req.keep_alive());
    res.content_length(size);
    res.body() = std::move(body);
    return res;
}

}}}} // namespace skynet::http::server::sync
