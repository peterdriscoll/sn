#include "session.hpp"
#include "request_handler.hpp"

#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>

namespace skynet { namespace http { namespace server { namespace sync {

session::session(boost::asio::ip::tcp::socket socket,
                 std::shared_ptr<const std::string> doc_root)
    : m_socket(std::move(socket)), m_doc_root(std::move(doc_root)) {}

int session::run()
{
    boost::beast::error_code ec;
    boost::beast::flat_buffer buffer;

    skynet::http::server::sync::request_handler handler(m_doc_root);

    for (;;) {
        boost::beast::http::request<boost::beast::http::string_body> req;
        boost::beast::http::read(m_socket, buffer, req, ec);
        if (ec == boost::beast::http::error::end_of_stream) break;
        if (ec) return -1;

        auto msg  = handler.handle(std::move(req));
        bool keep = msg.keep_alive();

        boost::beast::write(m_socket, std::move(msg), ec);
        if (ec) return -1;
        if (!keep) break;
    }

    m_socket.shutdown(boost::asio::ip::tcp::socket::shutdown_send, ec);
    return 0;
}

}}}} // namespace
